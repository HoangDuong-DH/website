---
layout: docs
title: Instagram
group: components
toc: true
---
## Style 01{.doc-toc-heading}
{{< docs/example>}}
{{< sample-code.inline >}}
<div class="py-10">
	{{ partial "elements/instagram/style-1" (dict "currentPage" . "data" "instagram" "space" "px-0" "slidesToShow" "3" "slidesToShow1366" "3" "slidesToShow992" "2" "slidesToShow768" "2" "slidesToShow576" "2")}}
</div>
{{</ sample-code.inline >}}
{{< /docs/example >}}
