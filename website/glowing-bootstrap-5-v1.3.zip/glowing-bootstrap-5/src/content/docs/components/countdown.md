---
layout: docs
title: Countdown
group: components
toc: true
---
## Style 01{.doc-toc-heading}
{{< docs/example>}}
{{< sample-code.inline >}}
<div class="py-10">
	{{ partial  "elements/countdown/style-1" (dict "time" "Oct 22, 2024 00:00:00" )}}
</div>
{{</ sample-code.inline >}}
{{< /docs/example >}}
